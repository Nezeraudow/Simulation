package eu.eisti.fintech.one.SimulationFin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimulationFinApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimulationFinApplication.class, args);
	}

}
